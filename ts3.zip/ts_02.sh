#!/bin/bash

echo "Trouble Shooting #2"
. 