#!/bin/bash

echo "Trouble Shooting #1"
. ~/devstack/accrc/admin/admin
sudo systemctl stop devstack@n-api.service
echo "Please start your trouble shooting!"

exit 0