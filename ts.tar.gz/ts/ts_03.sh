#!/bin/bash

echo "Trouble Shooting #2"
. ~/devstack/accrc/admin/admin
openstack role remove --user cinder --project service service
sudo systemctl stop devstack@c-api
sudo systemctl start devstack@c-api
echo "Please start your trouble shooting!"