#!/bin/bash

echo "Trouble Shooting #2"
. ~/devstack/accrc/admin/admin
sudo systemctl stop apache2
echo "Please start your trouble shooting!"

exit 0