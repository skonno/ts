#!/bin/bash

echo "Trouble Shooting #2"
source /home/openstack/kolla/admin-rc
sudo docker stop horizon
echo "Please start your trouble shooting!"

exit 0
