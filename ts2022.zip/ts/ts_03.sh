#!/bin/bash

echo "Trouble Shooting #3"
. 